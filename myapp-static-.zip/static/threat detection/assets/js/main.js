// Document Ready
$(document).ready(function() {
    // Remove loader
    setTimeout(function() {
        $('.loader-wrapper').fadeOut('slow');
    }, 1500);
    
    // Navbar scroll effect
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('.navbar').addClass('scrolled');
        } else {
            $('.navbar').removeClass('scrolled');
        }
    });
    
    // Counter animation
    $('.counter').each(function() {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).data('target')
        }, {
            duration: 2000,
            easing: 'swing',
            step: function(now) {
                // For percentage values
                if ($(this).data('target') <= 100) {
                    $(this).text(Math.ceil(now) + '%');
                } else {
                    // Add commas to large numbers
                    $(this).text(Math.ceil(now).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                }
            }
        });
    });
    
    // Tooltip initialization
    $('[data-bs-toggle="tooltip"]').tooltip();
    
    // Popover initialization
    $('[data-bs-toggle="popover"]').popover();
    
    // Animate elements when they come into view
    $(window).on('scroll', function() {
        $('.fade-in, .slide-in-left, .slide-in-right').each(function() {
            var elementPos = $(this).offset().top;
            var scrollPos = $(window).scrollTop();
            var windowHeight = $(window).height();
            
            if (scrollPos > elementPos - windowHeight + 100) {
                $(this).addClass('animated');
            }
        });
    }).scroll();
    
    // Processing button animation
    $('.btn-processing').click(function() {
        $(this).addClass('active processing');
        setTimeout(() => {
            $(this).removeClass('active processing');
        }, 2000);
    });
});

// Form submission with loading animation
function submitFormWithLoading(formId, callback) {
    const form = document.getElementById(formId);
    const submitBtn = form.querySelector('button[type="submit"]');
    
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
    submitBtn.disabled = true;
    
    // Simulate processing (replace with actual form submission)
    setTimeout(() => {
        submitBtn.innerHTML = 'Submit';
        submitBtn.disabled = false;
        if (callback) callback();
    }, 2000);
}

// Initialize all tooltips on a page
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Toggle password visibility
function togglePasswordVisibility(inputId, toggleId) {
    const passwordInput = document.getElementById(inputId);
    const toggleBtn = document.getElementById(toggleId);
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
    } else {
        passwordInput.type = 'password';
        toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
    }
}